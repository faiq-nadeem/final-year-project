export const UPDATE    = 'UPDATE'
export const FETCH_ALL = 'FETCH_ALL'
export const FETCH     = 'FETCH'

export const AUTH   = 'AUTH'
export const LOGOUT = 'LOGOUT'